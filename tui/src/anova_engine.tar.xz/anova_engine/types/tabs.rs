use strum::{Display, EnumIter, IntoEnumIterator};

#[derive(Debug, EnumIter, PartialEq, Display)]
pub enum PageTab {
    Device,
    Control,
}

#[derive(Debug)]
pub struct PageTabs {
    pub index: usize,
    pub tabs: Vec<PageTab>,
}

impl PageTabs {
    pub fn new() -> Self {
        Self {
            index: 0,
            tabs: PageTab::iter().collect(),
        }
    }

    pub fn current_tab<'a>(&'a self) -> &'a PageTab {
        &self.tabs[self.index]
    }

    pub fn is_device(&self) -> bool {
        self.current_tab() == &PageTab::Device
    }

    pub fn next(&mut self) {
        self.index = (self.index + 1) % self.tabs.len();
    }
}
