use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct AnovaDevice {
    #[serde(rename = "cookerId")]
    pub cooker_id: String,
    #[serde(rename = "type")]
    pub r#type: String,
    #[serde(default)]
    pub name: String,
    #[serde(default, rename = "pairedAt")]
    pub paired_at: String,
}

impl AnovaDevice {
    fn mock_devices() -> Vec<Self> {
        vec![
            Self {
                cooker_id: "1234".into(),
                r#type: "Pro".into(),
                name: "Anova Wifi".into(),
                paired_at: "some_time".into(),
            },
            Self {
                cooker_id: "5678".into(),
                r#type: "Pro".into(),
                name: "Anova Wifi".into(),
                paired_at: "some_other_time".into(),
            },
        ]
    }
}

#[derive(Debug)]
pub struct Devices {
    pub current_index: Option<usize>, // chosen
    pub next_index: Option<usize>,    // highlighted
    pub devices: Vec<AnovaDevice>,
}

impl Devices {
    pub fn mock() -> Self {
        Self {
            current_index: None,
            next_index: Some(0),
            devices: AnovaDevice::mock_devices(),
        }
    }

    pub fn current_device<'a>(&'a self) -> Option<&'a AnovaDevice> {
        match self.current_index {
            Some(i) => self.devices.get(i),
            None => None,
        }
    }

    pub fn next_device(&mut self) {
        if let Some(next_index) = self.next_index {
            self.next_index = Some((next_index + 1).min(self.devices.len() - 1))
        }
    }

    pub fn previous_device(&mut self) {
        if let Some(next_index) = self.next_index {
            self.next_index = Some(next_index.saturating_sub(1))
        }
    }

    pub fn update_device(&mut self) {
        match (self.next_index, self.current_index) {
            (Some(next_index), None) => self.current_index = Some(next_index),
            (Some(next_index), Some(current_index)) => match next_index == current_index {
                true => self.current_index = None,
                false => self.current_index = Some(next_index),
            },
            _ => {}
        }
    }
}
